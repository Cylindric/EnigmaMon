#include "serialGLCD.h"
#include "WProgram.h"

serialGLCD::serialGLCD()
{	/* Constructor.
	 Example: serialGLCD lcd;
	 */
}

void serialGLCD::clearLCD() 
{   /* Clears the display, eraseBlock is probably faster if you dont need to erase the entire screen.
	 Example: lcd.clearLCD();
	 */  
	Serial.print(0x7C,BYTE);
	Serial.print(0x00,BYTE);
}
void serialGLCD::setDebug(int l)
{	/*
	 0 = no messages
	 1 = binary messages, the display will echo a byte = command when the command is started and a byte = 0x00 when the command is finished
	 2 = text messages, useful when using a terminal. will echo "Entered Command n" when command n is started
	 and will echo "Exited Command n, RX_buffer=y" when the command is done, and will report how many bytes are in the recieve buffer
	 Example: lcd.setDebug(1);
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x01,BYTE);
	Serial.print(l);
}
void serialGLCD::backLight(int x) 
{   /* Sets backlight duty cycle. 0-100, 0=off.
	 Example: lcd.backLight(50);
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x02,BYTE);
	Serial.print(x,BYTE);
}
void serialGLCD::drawCircle(int x, int y, int r, int z) 
{   /* Draws a circle at (x,y) with radius r, draw/erase 
	 Example: lcd.drawCircle(30,30,10,1);
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x03,BYTE);
	Serial.print(x,BYTE);
	Serial.print(y,BYTE);
	Serial.print(r,BYTE);
	Serial.print(z,BYTE);
}
void serialGLCD::toggleCRLF()
{	/* Toggles CR/LF. each time this command is sent, 
	 wheather or not a CR automatically executes a LF is toggled. 
	 this is saved to EEPROM and is persistant over power cycles.
	 Example: lcd.toggleCRLF();
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x04,BYTE);
}
void serialGLCD::eraseBlock(int x1, int y1, int x2, int y2) 
{	/* Draws a block on the screen with clear or set pixels (depending on if the screen is inverted or not)
	 Example: lcd.eraseBlock(10,10,20,20);
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x05,BYTE);
	Serial.print(x1,BYTE);
	Serial.print(y1,BYTE);
	Serial.print(x2,BYTE);
	Serial.print(y2,BYTE);
}
void serialGLCD::resetLCD() 
{	/* Resets the LCD, clears the screen and resets x,y offsets to 0,0
	 Example: lcd.resetLCD();
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x06,BYTE);
}
void serialGLCD::changeBaud(int x)
{	/* Changes the baudrate.
	 1=4800
	 2=9600
	 3=19200
	 4=38400
	 5=57600
	 6=115200
	 Persistant over power-cycles. Transmitting to the screen during splash resets the baudrate to 115200
	 Example: lcd.changeBaud(2); // (9600)
	 */
	if(x<1) {
		x=1;
	}
	if(x>6) {
		x=6;
	}
	Serial.print(0x7C,BYTE);
	Serial.print(0x07,BYTE);
	Serial.print(x,BYTE);
}
void serialGLCD::toggleFont()
{	/* Toggles between the standard and AUX font. Only affects text written after the command.
	 Example: lcd.toggleFont();
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x08,BYTE);
}
void serialGLCD::setFontMode(int x)
{	/* Sets the mode for which text is written to the text.
	 0= AND
	 1= NAND
	 2= OR
	 3= NOR
	 4= XOR
	 5= NXOR
	 6= don't uses this one, will result in corrupted characters
	 7= COPY (this is the default, overwrites whatever is in the background, and is the only one that respects reverse)
	 Example: lcd.setFontMode(2); // (AND)
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x0A,BYTE);
	Serial.print(x,BYTE);
}
void serialGLCD::drawSprite(int x, int y, int n, int mode)
{	/* Draws a sprite saved in the backpack. x and y sets the upper left corner, 
	 n is the number of the stored sprite, n sets the mode (same modes ad text).
	 sprite 0 is the sparkfun logo, other uploaded sprites will be deleted if power is removed.
	 Example: lcd.drawSprite(10,10,0,7); // Draws the sparkfun logo
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x0B,BYTE);
	Serial.print(x,BYTE);
	Serial.print(y,BYTE);
	Serial.print(n,BYTE);
	Serial.print(mode,BYTE);
}
void serialGLCD::drawLine(int x1, int y1, int x2, int y2, int z) 
{	/* Draws a line from x1,y1 to x2,y2. z=1 to draw, z=0 to erase.
	 Example: lcd.drawLine(10,10,20,20,1); 
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x0C,BYTE);
	Serial.print(x1,BYTE);
	Serial.print(y1,BYTE);
	Serial.print(x2,BYTE);
	Serial.print(y2,BYTE);
	Serial.print(z,BYTE);
}
void serialGLCD::uploadSprite(int n, int w, int h, byte *data)
{	/* Uploads a sprite to the backpack, data must be 32 bytes long. 8 sprites can be stored (0-7).
	 The sparkfun logo is number 0, can be overwritten but reverts when power is removed. 
	 All uploaded sprites will be erased upon removal of power
	 Consult with firmware README for more info
	 Example: byte logo[] = {
	 0x80,0xc0,0x40,0x0c,0x3e,0xfe,0xf2,0xe0,0xf0,0xe0,
	 0xff,0x7f,0x3f,0x1f,0x1f,0x1f,0x1f,0x0f,0x07,0x03,
	 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	 0x00,0x00};
	 lcd.uploadSprite(7,10,16,logo); // Uploads the sparkfun logo as sprite number 7
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x0D,BYTE);
	Serial.print(n,BYTE);
	Serial.print(w,BYTE);
	Serial.print(h,BYTE);;
	for(int x = 0; x < 32;x++)
	{
		Serial.print(data[x],BYTE);
	}
}
void serialGLCD::drawBox(int x1, int y1, int x2, int y2, int z) 
{	/* Draws a rectangle starting from x1,y1 to x2,y2. z=1 for draw, z=0 for erase.
	 Example: lcd.drawBox(10,10,20,20,1);
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x0F,BYTE);
	Serial.print(x1,BYTE);
	Serial.print(y1,BYTE);
	Serial.print(x2,BYTE);
	Serial.print(y2,BYTE);
	Serial.print(z,BYTE);
}
void serialGLCD::togglePixel(int x, int y, int z) 
{     /* Toggles a pixel. x and y for coord, z=1 sets, z=0 erases.
	   Example: lcd.togglePixel(30,30,1);
	   */
	Serial.print(0x7C,BYTE);
	Serial.print(0x10,BYTE);
	if(x > 128) {
		Serial.print(128,BYTE);
	}
	else if(x < 0) {
		Serial.print(0,BYTE);
	}
	else {
		Serial.print(x,BYTE);
	}
	if(y > 64) {
		Serial.print(64,BYTE);
	}
	else if(y < 0) {
		Serial.print(0,BYTE);
	}
	else {
		Serial.print(y,BYTE);
	}
	if(z != 1 && z != 0) {
		Serial.print(1,BYTE);
	}
	else {
		Serial.print(z,BYTE);
	}
}
void serialGLCD::drawFilledBox(int x1, int y1, int x2, int y2, byte fill)
{	/* Same as drawBox, but accepts a fill byte. 0xFF for black, 0x00 for white. 
	 Other values can be used to create patterns (like 0x55). 
	 Example: drawFilledBox(10,10,20,20,0xFF);
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x12,BYTE);
	Serial.print(x1,BYTE);
	Serial.print(y1,BYTE);
	Serial.print(x2,BYTE);
	Serial.print(y2,BYTE);
	Serial.print(fill,BYTE);
	
}
void serialGLCD::reverseColor() 
{	/* Reverses the "color" (black on white / white on black)
	 Example: lcd.reverseColor();
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x14,BYTE);
}
void serialGLCD::toggleSplash()
{	/* Toggles the sparkfun logo during boot.
	 Example: lcd.toggleSplash();
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x15,BYTE);
}
void serialGLCD::drawData(int x, int y, int mode, int w, int h, byte *data)
{	/* Allows you to draw graphics to the screen like sprites, but the data doesn't have to be uploaded first, and there is no size
	 restrictions.(other than the drawable area of the display). 
	 Consult with firmware README for more info
	 Example:
	 byte data[]={0x00,0x12.....};
	 lcd.drawData(0,0,4,128,64,data); 
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x16,BYTE);
	Serial.print(x,BYTE);
	Serial.print(y,BYTE);
	Serial.print(mode,BYTE);
	Serial.print(w,BYTE);
	Serial.print(h,BYTE);
	int length = w*h/8;
	for(x = 0; x < length; x++) {
		Serial.print(data[x],BYTE);
	}
}
void serialGLCD::gotoPosition(int x, int y) 
{  	/* Sets the x and y offsets, text written after this command will start from x,y.
	 Example: lcd.gotoPosition(40,40);
	 */
	Serial.print(0x7C,BYTE);
	Serial.print(0x18,BYTE);
	Serial.print(x,BYTE);
	Serial.print(0x7C,BYTE);
	Serial.print(0x19,BYTE);
	Serial.print(y,BYTE);
}
void serialGLCD::gotoLine(int line)
{	/* Uses the gotoPosition function to select "line" 1-8 on the display. 
	 Text can be written between these lines using gotoPosition. This function makes it simpler.
	 Example: lcd.gotoLine(2);
	 */
	int y;
	if(line > 8) {
		line = 8;
	}
	else if(line < 1) {
		line = 1;
	}
	else {
		y = -8 + line * 8;
		gotoPosition(1,y);
	}
}